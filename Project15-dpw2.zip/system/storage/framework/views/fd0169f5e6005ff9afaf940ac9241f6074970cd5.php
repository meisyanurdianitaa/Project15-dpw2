<?php $__env->startSection('content'); ?>
<!-- start coding -->

   
   <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
      <h4>Detail Data User</h4>
    </div>

    <div class="container">
      <div class="card-body">
        <h3><?php echo e($user->nama); ?></h3>
            <hr>
            <p>
               <?php echo e("@".$user->username); ?> |
               Email : <?php echo e($user->email); ?> 
            </p>
            <p>
               No HP : <?php echo e($user->detail->no_handphone); ?> 
            </p>
        </div>  
      </div>
      
    </div>

    </div>
   </div>

<!-- end coding -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make("template.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\Project15-dpw2\system\resources\views/template/user/show.blade.php ENDPATH**/ ?>