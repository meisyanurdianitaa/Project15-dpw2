 <footer>
                    <div class="footer">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="footer_top">
                                        <div class="row">
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                                <div class="logo">
                                                    <a href="index.blade.php">FAEYZA</a>
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                                <ul class="sociel">
                                                    <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                                    <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 ">
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 ">
                                            <div class="address">
                                                <h3>Contact us </h3>
                                                <ul class="loca">
                                                    <li class="active">
                                                        <a href="#"><img src="<?php echo e(url('public')); ?>/icon/loc.png"
                                                                alt="#" /></a>Kalbar-Ketapang</li>
                                                    <li>
                                                        <a href="#"><img src="<?php echo e(url('public')); ?>/icon/call.png" alt="#" /></a>+12586954775
                                                    </li>
                                                    <li>
                                                        <a href="#"><img src="<?php echo e(url('public')); ?>/icon/email.png"
                                                                alt="#" /></a>faeyza@gmail.com </li>

                                                </ul>

                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6 col-sm-6">
                                            <div class="address">
                                                <h3>corporation</h3>
                                                <ul class="Links_footer">
                                                    <li class="active"><a href="#">My account</a> </li>
                                                    <li><a href="#"> Checkout</a> </li>
                                                    <li><a href="#">Login</a> </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-6 col-sm-6 ">
                                            <div class="address">
                                                <h3>why choose us</h3>
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                                    eiusmod tempor incididunt ut labore et dolore magna </p>
                                                <form class="newtetter">
                                                    <input class="tetter" placeholder="Your email" type="text"
                                                        name="Your email">
                                                    <button class="submit">Subscribe</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="copyright">
                            <div class="container">
                                <p>Copyright 2019 All Right<a href="https://html.design/"></a></p>
                            </div>
                        </div>
                    </div>

                </footer><?php /**PATH C:\xampp\xampp\htdocs\Project15-dpw2\system\resources\views/client/section/footer.blade.php ENDPATH**/ ?>