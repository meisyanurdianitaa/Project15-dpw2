<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="card mt-3 pt-3">
    <div class="row ml-1 mr-2 mb-3">
        <div class="col-md-8">
            <h4>HALAMAN BERANDA</h4>
        </div>
        <div class="card-body">

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\xampp\htdocs\Project15-dpw2\system\resources\views/template/dashboard.blade.php ENDPATH**/ ?>