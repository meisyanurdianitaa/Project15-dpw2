<?php  
 

 namespace App\Models;

 class UserDetails extends Model {
    protected $table = 'user_detail';
 }